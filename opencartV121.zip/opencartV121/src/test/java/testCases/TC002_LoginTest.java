package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseClass;

public class TC002_LoginTest extends BaseClass{
	
	@Test(groups={"Sanity","Master"})
	public void verify_login()
	{
		logger.info("************ Starting TC002_LoginTest ****************");
		try {
		HomePage hp = new HomePage(driver);
		
		hp.clickMyAccount();
		logger.info("click on my account");

		hp.clickLogin();
		logger.info("click on Login");
		
		LoginPage lp = new LoginPage(driver);
		lp.getEmail(p.getProperty("email"));
		logger.info("Enter email");
		
		lp.getPassword(p.getProperty("password"));
		logger.info("Enter password");
		
		lp.getLogin();
		logger.info("click on Login");
		
		MyAccountPage  macc = new MyAccountPage(driver);
		Boolean targetPage = macc.verifyHeader();
		
		//Assert.assertEquals(true, targetPage,"Login Failed");
		Assert.assertTrue(targetPage);
		logger.info("Login Successful");
		}
		catch(Exception e)
		{
			Assert.fail();
		}
		
		logger.info("************ Finished TC002_LoginTest ****************");

	}

}
