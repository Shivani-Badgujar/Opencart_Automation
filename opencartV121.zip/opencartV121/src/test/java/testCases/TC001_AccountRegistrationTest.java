package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseClass;

public class TC001_AccountRegistrationTest extends BaseClass{

	
	
	@Test(groups={"Regression","Master"})
	public void verify_account_registration()
	{
		logger.info("************ Starting TC001 AccountRegistrationTest ****************");
		try {
		HomePage hp = new HomePage(driver);
		hp.clickMyAccount();
		logger.info("Clicked on my account link");
		
		hp.clickRegister();
		logger.info("Clicked on my registration link");
		
		
		AccountRegistrationPage regpage = new AccountRegistrationPage(driver);
		
		logger.info("Providing customer details");
		regpage.setFirstName(randomString());
		regpage.setLastName(randomString());
		regpage.setEmail(randomString()+"@gmail.com");
		regpage.setTelephone(randomNum());
		
		String randomPassword = randomPassword();
		regpage.setPassword(randomPassword);
		regpage.setConfirmPassword(randomPassword);
		regpage.setPrivacyPolicy();
		regpage.setContinue();
		
		logger.info("Validating expected message");
		String confMsg = regpage.getConfirmationMsg();
		
		if(confMsg.equals("Your Account Has Been Created!"))
		{
			Assert.assertTrue(true);
		}
		else
		{
			logger.error("Test Failed..");
			logger.debug("Debug logs..");
			Assert.assertTrue(false);
		}
		//Assert.assertEquals(confMsg,"Your Account Has Been Created!!!");
		
		logger.info("\"************ Finished TC001 AccountRegistrationTest ****************\"");
	}
		catch(Exception e)
		{
			
			Assert.fail();
		}
	}
	

	
	
}
