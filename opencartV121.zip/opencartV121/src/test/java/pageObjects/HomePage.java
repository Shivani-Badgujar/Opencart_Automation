package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage{

	//constructor
	public HomePage(WebDriver driver)
	{
		super(driver);
	}
	
	
	//WebElements from home page
	//1.Account
	//2.Register
	
	// //span[normalize-space()='My Account']
	// @FindBy: This is a Selenium annotation used with PageFactory to locate elements on a web page. It tells Selenium how to find the element.
	@FindBy(xpath="//div[@id='top-links']/ul/li[2]/a")
	WebElement lnkMyAccount;
	
	// //a[normalize-space()='Register']
	@FindBy(xpath="//div[@id='top-links']/ul/li[2]/ul/li/a")
	WebElement lnkRegister;
	
	////ul[@class='dropdown-menu dropdown-menu-right']//a[normalize-space()='Login']
	@FindBy(xpath="//ul[@class='dropdown-menu dropdown-menu-right']//a[normalize-space()='Login']")
	WebElement lnkLogin;
	
	public void clickMyAccount()
	{
		lnkMyAccount.click();
	}
	
	public void clickRegister()
	{
		lnkRegister.click();
	}
	
	public void clickLogin()
	{
		lnkLogin.click();
	}
}
