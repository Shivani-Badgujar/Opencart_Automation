package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class BasePage {
	
	//driver instance variable
	WebDriver driver;
	
	//constructor having webdriver as a object parameter
	public BasePage(WebDriver driver)
	{
		//assigns the passed-in WebDriver to the class's instance variable. 
		//The this keyword is used to distinguish between the class variable and the constructor parameter (both named driver).
		this.driver=driver;
		
		//Use the provided driver to locate elements.
		//Initialize the elements in the current class (this).
		PageFactory.initElements(driver, this);
	}

}
